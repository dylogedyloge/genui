"use client";

import React from "react";
import ChatInterface from "@/components/chat-interface";

const MainChatPage = () => {
  return <ChatInterface />;
};

export default MainChatPage;
